# I have implemented functionality in SwiftUI

Data Folder: where all the json files are present
Helper: Made preference manager class to store data of accounts so that next time when user comes, we can get that data from preference
Model: Model class of accounts and transaction entities
ViewModel: Implemented logic to fetch data from json file
View: UI implementation with SwiftUI



